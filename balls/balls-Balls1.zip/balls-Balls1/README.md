# BALLS
# DATABASE OF ALL GEN 9 POKEBALLS COLLATED COLLECTION BY XGC 
"All your balls are belong to Us"

**Repository Contents:**
* .png embed ready of all of the balls used in the SV games as of Teal Mask (presumably they won't add a new ball with Area 0 DLC )

## Credits
* Project Pokemon for collating the majority of the assets in the collections. 
* Xieon - [Xieon's Gaming Corner](https://discord.gg/xieon) 
* Rich (XGC)  - thanks for initially collecting the balls images independant of PP Org 

## Disclaimer on Dependencies: 
- project pokemon, the developers of PKHex, PkHexPlugins are not affiliated with officially or officially endorese this project. 
- Sysbot or any of it's forks that XGC's work forks from, or draws from,  such as Berichans fork, the original KWSH Sysbot, Notforkbot, and Kois Forkbot are not in any official collaboration or have endorsed any XGC projeccts. 
Please if you have any issues with something that is now or in the future posted on the XGC Repositories contact XGC - the easiest way is via discord: 
https://discord.gg/xieon
